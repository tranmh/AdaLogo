package adalogo.visitor;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * programm counter.
 * used mainly for varMonitor to keep track of changed variables.
 * started and counted by interpreter.
 */
public class ProgramCounter {

    private int pc;

    public ProgramCounter() {
        pc = 0;
    }

    public void increment() {
        pc = pc + 1;
        fireCounterIncremented();
    }

    public int getValue() {
        return pc;
    }

    public void reset() {
        pc = 0;
        fireCounterReset();
    }

    //-------------------------------------------------------------------------
    //event listener architecture

    private Set listeners = new HashSet();

    /**
     * interface for pc listener listeners
     * mainly implemented by varmonitor varnodes
     */
    public interface ProgramCounterListener {
        void counterReset();
        void counterIncremented();
    }

    public void addProgramCounterListener(ProgramCounterListener listener) {
        listeners.add(listener);
    }

    public void removeProgramCounterListener(ProgramCounterListener listener) {
        listeners.remove(listener);
    }

    private void fireCounterIncremented() {
        for (Iterator i = listeners.iterator(); i.hasNext(); ) {
            ProgramCounterListener l = (ProgramCounterListener) i.next();
            l.counterIncremented();
        }
    }

    private void fireCounterReset() {
        for (Iterator i = listeners.iterator(); i.hasNext(); ) {
            ProgramCounterListener l = (ProgramCounterListener) i.next();
            l.counterReset();
        }
    }

}
