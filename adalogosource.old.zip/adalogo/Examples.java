package adalogo;

import java.io.InputStream;

/**
 * static class to load examples.
 * the example file are in the example directory
 * which will be packed in the jar.
 * files from the jar can only be opened as inputstream.
 */
public class Examples {

    /**
     * hardcoded list of examples.
     * this is necessary because a dir in a jar cannot be parsed
     * (at least i have no idea how).
     * the first in the list should always be template.adl
     */
    public static final String[] example = {
            "template.adl",
            "befehle.adl",
            "kreis.adl",
            "quadrat.adl",
            "n_eck.adl",
            "ada.adl",
            "schnauzbart.adl",
            "fibonacci.adl",
            "dreieck.adl",
            "gerade_ungerade.adl",
            "pusteblume.adl",
            "Parabel.adl",
            "schachbrett.adl",
            //"stern_fraktal.adl",
            "dreieck_fraktal.adl",
            "hilbert.adl"
    };

    /**
     * returns the template.adl stream.
     * this should be equivalent with getExample(0);
     * this will be called by editor to load editor with template
     */
    public static InputStream getTemplate() {
        return Examples.class.getResourceAsStream("/examples/template.adl");
    }

    /**
     * returns the stream for example number number
     */
    public static InputStream getExample(int number) {
        return Examples.class.getResourceAsStream("/examples/"+example[number]);
    }

    /*
     * cannot use this because files from jar can only be accessed as stream.
     * this will only work when the files are on disk.
     * left here for nostalgic reasons :)
     */
    /*
    public Action[] getExampleActions(Engine engine) {

        URL url = Examples.class.getResource("/examples");
        File dir = new File(url.getPath());
        File[] file = dir.listFiles();
        Action[] action = new Action[file.length];
        for (int i = 0; i < file.length; i++) {
            //System.out.println(file[i]);
            action[i] = new ExampleAction(engine, file[i]);
        }

        return action;

    }
    /**/

}
